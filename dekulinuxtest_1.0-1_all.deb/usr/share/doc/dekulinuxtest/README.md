# deku_test

## Ensure you have GTK installed on your linux system
### Run the python application
`python dekulinux.py`
